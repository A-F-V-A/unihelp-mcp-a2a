# UniHelp: paquete de datos del experimento (2026-09-27)

Todos los datos crudos que el experimento produjo hasta el 2026-09-27, **clasificados**
por lo que sirven para el analisis, **consolidados** en tablas planas y
acompañados del **catalogo de las 43 metricas** del plan de medicion con lo que
ya esta calculado, lo que se puede calcular con estos datos y lo que falta.

- Generado por `experiment/resultados/paquete.py` sobre el commit `591925551e1d` del
  repositorio (se regenera identico con `uv run python resultados/paquete.py --fecha 2026-09-27`).
- Fuente: `experiment/resultados/` (corridas archivadas y versionadas, decision 47).
- Este paquete **no calcula metricas** (regla RM-02): las cifras de metricas son
  transcripcion literal de los `resultados.json` que produjo el cuaderno
  `experiment/analisis.ipynb`; las tablas de `consolidado/` son los campos crudos
  de cada traza aplanados, sin agregar.
- La integridad de cada archivo se comprueba con `SHA256SUMS.txt`
  (`sha256sum -c SHA256SUMS.txt`).

---

## 1. Resumen en cifras

| Concepto | Cantidad |
| --- | --- |
| Corridas archivadas | 15 (6 principales, 5 parciales, 4 historicas) |
| Ejecuciones con resultado (filas de `ejecuciones.csv`) | 3,382 (2,560 principales, 702 parciales, 120 historicas) |
| Trazas completas (con tiempos, tokens y herramientas) | 3,302 |
| Llamadas a herramientas registradas | 10,043 |
| Saltos entre agentes (B2 en proceso, B3 por A2A) | 2,811 |
| Ejecuciones en cuarentena (fallo de infraestructura, excluidas) | 581 |
| Filas de metricas calculadas / contrastes | 5,100 / 1,104 |
| Metricas del plan | 43: 33 calculadas, 0 con datos crudos ya disponibles, 10 a las que les falta un insumo |
| Tareas del conjunto de evaluacion | 40 (10 informativas, 10 de diagnostico, 10 compuestas, 10 adversariales) |
| Modelos | OpenAI gpt-5.5, gpt-5.4, gpt-5.4-mini, gpt-4.1-mini; Ollama Qwen2.5 7B local; Gemini 3.8-flash, 3.5-flash, 3.1-flash-lite, 3.1-pro-preview |

---

## 2. Que hay en el zip

```text
README.md                    este documento
SHA256SUMS.txt               huella SHA-256 de cada archivo del paquete
catalogo/
  corridas.csv               una fila por corrida: clase, modelo, cobertura, commit, semilla
  metricas.csv               las 43 metricas: definicion, formula, situacion, campos presentes/ausentes
  tareas.csv                 las 40 tareas: categoria, servicios, ejes
  metricas.yaml              registro oficial de metricas (fuente de todo nombre de campo)
  tarifas.yaml               tarifa de lista por modelo con su fuente y fecha (costo M4.7)
  esquemas/                  JSON Schema de traza, insumos, metricas y resultados
consolidado/                 TODO el experimento en tablas planas (CSV UTF-8 con BOM)
  ejecuciones.csv            una fila por ejecucion (unidad de observacion)
  llamadas-herramientas.csv  una fila por llamada a herramienta dentro de una ejecucion
  saltos-a2a.csv             una fila por delegacion orquestador -> especialista (B2, B3)
  cuarentena.csv             ejecuciones apartadas por fallo de infraestructura
  metricas-calculadas.csv    cada valor que calculo el cuaderno, con su intervalo y su n
  contrastes.csv             cada contraste entre arquitecturas, con intervalo y si incluye el cero
datos/                       copia INTEGRA de cada corrida, separada por clase
  A-principal/<corrida>/     matrices completas: la base del analisis
  B-parcial/<corrida>/       campañas Gemini cortadas por saldo
  C-historico/<corrida>/     lineas base de B0 anteriores a B1-B3
tareas/                      los 40 YAML de docs/tasks (respuesta esperada de cada tarea)
informes/                    informes de resultados de cada campaña, plan de medicion (docs/09),
                             historias de medicion y guia de las carpetas archivadas
```

Dentro de cada carpeta de `datos/`:

| Archivo | Formato | Que es |
| --- | --- | --- |
| `trazas.jsonl` | JSON Lines, una traza por linea, valida contra `catalogo/esquemas/traza.schema.json` | **El dato crudo principal.** Todo lo que paso en una ejecucion |
| `puntuaciones.jsonl` | JSON Lines, clave `run_id` | `exito` (compuerta AND juez), `compuerta_automatica`, `veredicto_juez` y `motivos` de fallo de la compuerta |
| `veredictos-juez.jsonl` | JSON Lines, clave `run_id` | Juez: `veredicto`, `puntos_cubiertos`, `puntos_sin_respaldo`, `prohibiciones_violadas`, `abstencion` |
| `juez.json` | JSON | Quien juzgo, huella del prompt, aprobadas, exitos quitados, reprobadas solo por falta de respaldo, consistencia con la pasada v1 |
| `cuarentena/trazas.jsonl` | JSON Lines: `traza`, `errores`, `estado_original` | Ejecuciones que no se cuentan (RM-15) |
| `manifiesto.json` | JSON | Procedencia: commit, semilla, modo, conteos, fallos de infraestructura; bloque `interrumpida` en las parciales |
| `manifiesto-cuaderno.json` | JSON | Procedencia de la ejecucion del cuaderno |
| `huellas-esperadas.json` | JSON | Huella del estado inicial esperada por tarea (M7.2) |
| `resultados.json` | JSON, valido contra `resultados.schema.json` | **Las metricas calculadas** de esa corrida |
| `tabla_1/2/4/7.csv`, `figura_1..4.svg` | CSV / SVG | Tablas y figuras del cuaderno (efectividad, latencia, costo, control) |
| `reejecuciones.md` | Markdown | Registro de reejecuciones (vacio si no hubo) |

---

## 3. Clasificacion de las corridas

La clase sale de la **cobertura** de cada corrida, no de sus resultados:

- **A-principal**: Matriz completa (todas las ejecuciones planificadas con traza valida), cuatro arquitecturas, codigo con B0-B3 implementados y prompt base 1.4.0. Admite los cuatro contrastes.
- **B-parcial**: Campaña interrumpida por el proveedor (402, saldo agotado): las trazas son validas una por una, pero la matriz esta incompleta. Sus contrastes usan solo las tareas pareadas disponibles.
- **C-historico**: Linea base de B0 sola, anterior a B1-B3 o con prompt anterior. No admite contrastes entre arquitecturas; documenta la evolucion del agente.

| Clase | Carpeta | Modelo | Esfuerzo | Validas / planificadas | Compuerta | Tareas B0/B1/B2/B3 | En las 4 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A-principal | `2026-09-25-campana-gpt-4-1-mini-2025-04-14-r3` | gpt-4.1-mini-2025-04-14 | — | 480 / 480 | 375 | 40/40/40/40 | 40 |
| A-principal | `2026-09-25-campana-gpt-5-4-2026-03-05-r3` | gpt-5.4-2026-03-05 | — | 480 / 480 | 435 | 40/40/40/40 | 40 |
| A-principal | `2026-09-25-campana-gpt-5-4-mini-2026-03-17-r3` | gpt-5.4-mini-2026-03-17 | — | 480 / 480 | 361 | 40/40/40/40 | 40 |
| A-principal | `2026-09-25-campana-gpt-5-5-2026-04-23-r3` | gpt-5.5-2026-04-23 | — | 480 / 480 | 444 | 40/40/40/40 | 40 |
| A-principal | `2026-09-25-campana-unihelp-qwen2-5-7b-instruct-q4_K_M-ctx16k-r3` | unihelp-qwen2.5:7b-instruct-q4_K_M-ctx16k | — | 480 / 480 | 211 | 40/40/40/40 | 40 |
| A-principal | `2026-09-25-cuatro-arquitecturas-r1` | gpt-5.5-2026-04-23 | — | 160 / 160 | 147 | 40/40/40/40 | 40 |
| B-parcial | `2026-09-25-campana-gemini-3-1-flash-lite-r3-parcial-402` | gemini-3.1-flash-lite | none | 136 / 480 | 109 | 27/24/24/26 | 5 |
| B-parcial | `2026-09-25-campana-gemini-3-1-pro-preview-low-r3-parcial-402` | gemini-3.1-pro-preview | low | 35 / 480 | 32 | 10/6/9/7 | — |
| B-parcial | `2026-09-25-campana-gemini-3-5-flash-r3-parcial-402` | gemini-3.5-flash | none | 94 / 480 | 83 | 23/18/20/19 | 3 |
| B-parcial | `2026-09-25-campana-gemini-3-8-flash-r3-parcial-402` | gemini-3.8-flash | none | 89 / 480 | 85 | 21/16/20/18 | 1 |
| B-parcial | `2026-09-26-campana-gemini-3-1-flash-lite-r3` | gemini-3.1-flash-lite | none | 348 / 480 | 267 | 40/40/37/37 | 34 |
| C-historico | `2026-09-23-b0-gpt-5.4-mini` | gpt-5.4-mini-2026-03-17 | — | 40 / 40 | — | — (sin trazas) | — |
| C-historico | `2026-09-24-b0-gpt-5.5-prompt-1.3.0` | gpt-5.5-2026-04-23 | — | 40 / 40 | 33 | — (sin trazas) | — |
| C-historico | `2026-09-24-b0-gpt-5.5-prompt-1.4.0` | gpt-5.5-2026-04-23 | — | 40 / 40 | 36 | — (sin trazas) | — |
| C-historico | `2026-09-25-ollama-b0-qwen2.5-7b-r1` | unihelp-qwen2.5:7b-instruct-q4_K_M-ctx16k | — | 40 / 40 | 0 | 40/0/0/0 | — |

**Que usar para que.** Las conclusiones del estudio (H1 MCP, H2 multiagente,
H3 A2A) se apoyan en la clase A: cinco campañas de 480 ejecuciones (40 tareas x
4 arquitecturas x 3 repeticiones) con cinco modelos distintos, mas la corrida
conjunta de 160. La clase B sirve como replica con otro proveedor (Gemini), con
la reserva de su `n`; la de flash-lite del 26 de septiembre cubre 34 tareas
pareadas en las cuatro arquitecturas. La clase C no entra a los contrastes.
**Todos los modelos entran al analisis como factor** (decision 49): cada
hipotesis se evalua con los contrastes dentro de cada modelo y la conclusion se
lee a traves de modelos; no se promedian cifras entre modelos.

---

## 4. El dato crudo: la traza de una ejecucion

La **unidad de observacion** es la ejecucion (`run_id` = tarea | arquitectura |
repeticion | marca); la **unidad de analisis** es la tarea (n = 40, nunca 480
ni 800: RM-03). Cada traza trae:

| Bloque | Campos | Para que metricas |
| --- | --- | --- |
| Identidad | `run_id`, `trace_id`, `task_id`, `condition` (B0-B3), `repetition` | Todas |
| `provenance` | `modelo_id`, `version_codigo`, `semilla`, `config_hash`, `state_hash_inicial`, `llm_mode`, `dataset_version` | Procedencia, M7.2 |
| `model` | `provider`, `id`, `temperature` (0,2), `top_p`, `max_tokens` | Procedencia |
| `timing` | `total_ms` y `breakdown.llm_ms`, `tool_exec_ms`, `transport_ms`, `orchestration_ms` (reloj monotono, RM-06) | M4.1, M4.2 |
| `usage` | `input_tokens`, `output_tokens`, `cached_input_tokens`, `llm_calls`, `cost_usd_est` | M4.4, M4.6, M4.7 |
| `tool_calls[]` | `seq`, `nombre`, `args`, `isError`, `resultado_status`, `resultado`, `latency_ms`, `agente`, `transporte` (en_proceso / mcp / a2a) | M2.1-M2.6, M3.1 |
| `a2a` | `mensajes_totales`, `estados[]` del ciclo de tarea, `hops[]` con `rtt_ms`, `procesamiento_receptor_ms` y `transport_ms` = rtt - receptor (RM-05) | M4.2, M4.5 |
| `server_audit[]` | `accion`, `resultado`, `actor`, `motivo`, `tokenValido`, `payloadHash` (huella, nunca el cuerpo: RM-09) | M5.1, M5.2, M5.4, M5.6 |
| `conversation[]` | Turnos usuario/agente con el texto | M3.x (juez), M5.7 |
| `outcome` | `status` (ok, timeout, limite_herramientas, error_agente, error_infraestructura, esquema_invalido), `final_answer`, `final_json` (clasificacion, confianza, politicas_citadas, diagnostico, ticket, confirmacion), `confirmacion_solicitada`, `confirmacion_otorgada`, `tickets_creados` | M1.x, M3.1, M3.5, M3.6, M5.3, M5.4 |
| `errors[]` | Errores del turno | M1.5, M7.3 |

Como cuenta cada `outcome.status` (tabla congelada del plan, seccion 13):
`ok` entra en todo; `timeout`, `limite_herramientas` y `error_agente` cuentan
como **fallo** de la arquitectura en efectividad y se excluyen de latencia;
`error_infraestructura` y `esquema_invalido` se **excluyen** de todo y van a
cuarentena (RM-15).

### Diccionario de `consolidado/ejecuciones.csv`

Una fila por ejecucion. Es la traza aplanada: los valores son los de la traza
y la puntuacion, sin agregar.

| Columna | Origen |
| --- | --- |
| `clasificacion`, `carpeta`, `proveedor`, `modelo_id` | Corrida a la que pertenece |
| `run_id`, `trace_id`, `task_id`, `categoria`, `arquitectura`, `repeticion` | Identidad; `categoria` sale de `tareas/` |
| `outcome_status` | `outcome.status` |
| `exito`, `compuerta_automatica`, `veredicto_juez`, `motivos_fallo` | `puntuaciones.jsonl` (motivos separados por `;`, p. ej. `herramienta_prohibida:proponer_ticket`) |
| `started_at`, `ended_at` | Marcas ISO 8601 (solo referencia; las duraciones NO se restan de aqui: RM-06) |
| `total_ms`, `llm_ms`, `tool_exec_ms`, `transport_ms`, `orchestration_ms` | `timing` |
| `input_tokens`, `output_tokens`, `cached_input_tokens`, `llm_calls`, `cost_usd_est` | `usage` |
| `a2a_mensajes_totales`, `a2a_saltos_registrados` | `a2a.mensajes_totales` y numero de filas de `a2a.hops` |
| `tool_calls_registradas`, `herramientas_en_orden` | Numero de filas de `tool_calls` y sus nombres en orden (`>`) |
| `final_*` | `outcome.final_json`: clasificacion, confianza, politicas citadas, servicio, estado, prioridad |
| `confirmacion_solicitada`, `confirmacion_otorgada`, `tickets_creados` | `outcome` |
| `errores` | `errors[].mensaje` |
| `state_hash_inicial`, `semilla`, `version_codigo`, `llm_mode`, `temperatura`, `dataset_version` | `provenance` y `model` |

Las filas de la clase C sin traza traen solo identidad y puntuacion.
`llamadas-herramientas.csv` y `saltos-a2a.csv` se unen a `ejecuciones.csv` por
`carpeta` + `run_id`.

### Formato de las metricas calculadas

Cada `resultados.json` (y su transcripcion en `consolidado/metricas-calculadas.csv`)
trae, por metrica, `estado` (`calculada`, `sin_datos` con `motivo_estado`, o
`pendiente`) y filas con: `arquitectura`, `estadistico` (`media_entre_tareas`,
`mediana_entre_tareas`, `proporcion`, ...), `dimensiones` (p. ej.
`categoria=compuesta`, `componente=transporte`, `tokens=total`), `valor`,
`intervalo` (`inferior`, `superior`, `nivel` 0,95), `n_tareas` y
`n_observaciones`. Las proporciones van en [0, 1] (multiplicar por 100 para %),
las latencias en milisegundos y los tokens en unidades. `contrastes.csv` trae
`contraste` (`B1-B0`, `B2-B1`, `B3-B2`, `B3-B1`), `diferencia` (media de
diferencias por tarea), intervalo, `n_tareas` pareadas e `incluye_cero`.

Metodo: bootstrap percentil **pareado por tarea**, 10 000 replicas, nivel 95 %,
semilla 20261014. Primero se agrega dentro de cada tarea (media o mediana de
sus repeticiones) y despues entre tareas, para que ninguna tarea pese mas. Los
intervalos se leen como estimacion, **no como aprobado/reprobado** (RM-14):
solo las metricas de tipo `umbral` tienen un valor de referencia.

---

## 5. Las 43 metricas: que hay, que se puede obtener y que falta

El detalle completo (definicion, formula, unidad, direccion, agregacion, que no
captura, campos fuente presentes y ausentes verificados contra las trazas) esta
en `catalogo/metricas.csv`. Resumen:

### 5.1 Ya calculadas (33)

Estan en cada `resultados.json` y en `consolidado/metricas-calculadas.csv`.

| Codigo | Metrica | Rol | Hipotesis | Pendiente |
| --- | --- | --- | --- | --- |
| M1.1 | Tasa de éxito | primaria | H1,H2,H3 | — |
| M1.2 | Tasa de éxito por categoría | primaria | H2,H3 | — |
| M1.3 | Éxito consistente | secundaria | H1,H2,H3 | — |
| M1.4 | Tareas de resultado mixto | secundaria | H1,H2,H3 | — |
| M1.5 | Fallos por tipo | descriptiva | H1,H2,H3,H4 | — |
| M2.1 | Cobertura de herramientas obligatorias | secundaria | H1,H2,H3 | — |
| M2.2 | Tasa de invocación prohibida | primaria | H4 | — |
| M2.3 | Validez de argumentos | secundaria | H1 | — |
| M2.4 | Cumplimiento del orden parcial | secundaria | H2,H3,H4 | — |
| M2.5 | Llamadas superfluas | descriptiva | H2,H3 | — |
| M2.6 | Tasa de error de herramienta | descriptiva | H1 | — |
| M3.1 | Fidelidad de citación | primaria | H1,H2,H3 | — |
| M3.2 | Cobertura de puntos clave | secundaria | H2,H3 | veredictos del juez LLM (veredictos-juez.jsonl) |
| M3.3 | Violación de prohibiciones de respuesta | secundaria | H1,H2,H3 | veredictos del juez LLM (veredictos-juez.jsonl) |
| M3.4 | Abstención correcta | secundaria | H1 | veredictos del juez LLM (veredictos-juez.jsonl) |
| M3.5 | Exactitud de la prioridad | secundaria | H2,H3 | — |
| M3.6 | Exactitud de clasificación | descriptiva | H2,H3 | — |
| M4.1 | Latencia de extremo a extremo | primaria | H3 | — |
| M4.2 | Descomposición de la latencia | primaria | H3 | — |
| M4.4 | Llamadas al modelo por ejecución | secundaria | H2,H3 | — |
| M4.5 | Mensajes entre agentes | secundaria | H3 | — |
| M4.6 | Tokens por ejecución | primaria | H3 | — |
| M4.7 | Costo estimado por ejecución | secundaria | H3 | — |
| M5.1 | Escrituras no autorizadas | primaria | H4 | — |
| M5.2 | Tasa de rechazo mecánico | primaria | H4 | — |
| M5.3 | Solicitud de confirmación | primaria | H4 | — |
| M5.4 | Falso bloqueo | primaria | H4 | — |
| M5.5 | Resistencia adversarial por vector | primaria | H4 | — |
| M5.6 | Cumplimiento del alcance de capacidades | secundaria | H4 | — |
| M5.7 | Exposición de datos de terceros | secundaria | H4 | — |
| M7.1 | Completitud de trazas | control | ninguna | — |
| M7.2 | Integridad del estado inicial | control | ninguna | — |
| M7.3 | Tasa de reejecución por infraestructura | control | ninguna | — |

Notas: **M1** y **M5.5** usan `exito = compuerta AND juez` (decision 53); **M3.2**
se da contra todos los puntos y contra los que tenian respaldo en lo recuperado.
**M4.7** multiplica los tokens de cada ejecucion por la tarifa de
lista de `catalogo/tarifas.yaml` (decision 50). **M3.5** se mide sobre 5 tareas,
no 20 (decision 51, pendiente). **M5.2** y **M5.6** estan calculadas pero sin
valor: ninguna corrida intento lo que esas defensas rechazan. Las definiciones
operativas de M2, M3 y M5 estan en la decision 51 y en `catalogo/metricas.csv`.

### 5.2 Con los datos crudos disponibles pero sin implementar (0)

Ninguna. Las 16 que tenian sus datos en las trazas (M2.1-M2.6, M3.1, M3.5, M3.6 y M5.1-M5.7) se implementaron el 27 de septiembre de 2026 y se recalcularon sobre todas las corridas sin volver a ejecutar ninguna tarea (decision 51).

### 5.3 Les falta un insumo que ninguna corrida produjo (10)

| Codigo | Metrica | Rol | Hipotesis | Insumo que falta |
| --- | --- | --- | --- | --- |
| M4.3 | Piso de latencia del transporte | primaria | H3 | microbenchmark de transporte sin modelo (bench-transport.json, D9) |
| M6.1 | Archivos modificados | primaria | H1 | experimento de extensibilidad: commit aislado de la sexta herramienta |
| M6.2 | Líneas netas | secundaria | H1 | experimento de extensibilidad: commit aislado de la sexta herramienta |
| M6.3 | Componentes que exigen redespliegue | primaria | H1 | experimento de extensibilidad: bitacora de servicios reiniciados |
| M6.4 | Tiempo hasta prueba verde | primaria | H1 | experimento de extensibilidad: minutos hasta prueba verde |
| M6.5 | Regresión sin tocar pruebas existentes | primaria | H1 | experimento de extensibilidad: resultado de la suite en el commit aislado |
| M7.4 | Acuerdo entre revisores | control | ninguna | planilla de dos revisores humanos sobre el 20 % de las ejecuciones |
| M7.5 | Acuerdo entre juez y humano | control | ninguna | veredictos del juez y planilla humana adjudicada |
| M7.6 | Determinismo en reproducción | control | ninguna | reproduccion de la corrida desde casetes (modo replay) |
| M7.7 | Sobrecosto de la instrumentación | control | ninguna | corrida de control con instrumentacion completa y minima |

Para cerrarlas: hacer la **calificacion humana** de la
muestra del 20 % (M7.4, M7.5), el **microbenchmark de transporte** (M4.3), una
**reproduccion desde casetes** (M7.6), la **corrida de control** de
instrumentacion (M7.7) y el **experimento de extensibilidad** con la sexta
herramienta (M6.1-M6.5).

---

## 6. Cifras principales ya calculadas

Transcritas de `metricas-calculadas.csv` y `contrastes.csv` (IC 95 %).

### Efectividad M1.1 (% de exito por tarea)

| Corrida | B0 | B1 | B2 | B3 |
| --- | --- | --- | --- | --- |
| gpt-4.1-mini-2025-04-14, 2026-09-25 | 23.3 [12.5; 35.8] | 24.2 [13.3; 35.8] | 23.3 [12.5; 35.0] | 28.3 [16.7; 40.8] |
| gpt-5.4-2026-03-05, 2026-09-25 | 33.3 [20.8; 46.7] | 34.2 [21.7; 47.5] | 33.3 [20.8; 46.7] | 30.0 [17.5; 43.3] |
| gpt-5.4-mini-2026-03-17, 2026-09-25 | 18.3 [9.2; 29.2] | 18.3 [9.2; 29.2] | 18.3 [9.2; 28.3] | 13.3 [5.8; 22.5] |
| gpt-5.5-2026-04-23, 2026-09-25 | 40.8 [26.7; 55.0] | 34.2 [20.8; 48.3] | 48.3 [34.2; 62.5] | 50.8 [35.8; 65.0] |
| unihelp-qwen2.5:7b-instruct-q4_K_M-ctx16k, 2026-09-25 | 3.3 [0.8; 6.7] | 8.3 [1.7; 16.7] | 1.7 [0.0; 4.2] | 6.7 [1.7; 13.3] |
| gpt-5.5-2026-04-23, 2026-09-25, 1 rep. | 45.0 [30.0; 60.0] | 37.5 [22.5; 52.5] | 47.5 [32.5; 62.5] | 45.0 [30.0; 60.0] |
| gemini-3.1-flash-lite (none), 2026-09-25, *parcial 136/480* | 35.2 [18.0; 53.6] n=27 | 22.9 [7.7; 40.5] n=24 | 29.2 [12.0; 48.0] n=24 | 23.1 [8.0; 40.6] n=26 |
| gemini-3.1-pro-preview (low), 2026-09-25, *parcial 35/480* | 80.0 [50.0; 100.0] n=10 | 58.3 [16.7; 100.0] n=6 | 33.3 [0.0; 66.7] n=9 | 28.6 [0.0; 66.7] n=7 |
| gemini-3.5-flash (none), 2026-09-25, *parcial 94/480* | 43.5 [23.1; 64.3] n=23 | 38.9 [16.7; 62.5] n=18 | 25.0 [6.7; 45.0] n=20 | 26.3 [6.2; 47.4] n=19 |
| gemini-3.8-flash (none), 2026-09-25, *parcial 89/480* | 38.1 [17.6; 59.1] n=21 | 28.1 [8.3; 50.0] n=16 | 37.5 [17.6; 59.1] n=20 | 38.9 [16.7; 62.5] n=18 |
| gemini-3.1-flash-lite (none), 2026-09-26, *parcial 348/480* | 30.8 [17.5; 45.8] n=40 | 30.0 [16.7; 44.2] n=40 | 27.0 [13.7; 41.2] n=37 | 26.1 [13.8; 40.0] n=37 |

### Contrastes de M1.1 (puntos porcentuales)

| Corrida | B1 - B0 (MCP) | B2 - B1 (multiagente) | B3 - B2 (A2A) | B3 - B1 |
| --- | --- | --- | --- | --- |
| gpt-4.1-mini-2025-04-14, 2026-09-25 | +0.8 [-3.3; 5.8] n=40 | -0.8 [-10.8; 9.2] n=40 | +5.0 [-2.5; 13.3] n=40 | +4.2 [-4.2; 12.5] n=40 |
| gpt-5.4-2026-03-05, 2026-09-25 | +0.8 [-5.0; 6.7] n=40 | -0.8 [-6.7; 5.0] n=40 | -3.3 [-8.3; 1.7] n=40 | -4.2 [-11.7; 2.5] n=40 |
| gpt-5.4-mini-2026-03-17, 2026-09-25 | +0.0 [-5.8; 5.8] n=40 | +0.0 [-8.3; 7.5] n=40 | -5.0 [-10.0; 0.0] n=40 | -5.0 [-13.3; 2.5] n=40 |
| gpt-5.5-2026-04-23, 2026-09-25 | -6.7 [-14.2; -0.8] n=40 | +14.2 [5.0; 24.2] n=40 | +2.5 [-0.8; 5.8] n=40 | +16.7 [5.8; 28.3] n=40 |
| unihelp-qwen2.5:7b-instruct-q4_K_M-ctx16k, 2026-09-25 | +5.0 [0.8; 10.8] n=40 | -6.7 [-14.2; -0.8] n=40 | +5.0 [0.0; 11.7] n=40 | -1.7 [-8.3; 3.3] n=40 |
| gpt-5.5-2026-04-23, 2026-09-25, 1 rep. | -7.5 [-20.0; 5.0] n=40 | +10.0 [0.0; 22.5] n=40 | -2.5 [-7.5; 0.0] n=40 | +7.5 [-2.5; 17.5] n=40 |
| gemini-3.1-flash-lite (none), 2026-09-25, *parcial 136/480* | +7.1 [0.0; 17.9] n=14 | +3.1 [0.0; 10.7] n=16 | -13.3 [-33.3; 0.0] n=15 | -10.0 [-26.3; 0.0] n=15 |
| gemini-3.1-pro-preview (low), 2026-09-25, *parcial 35/480* | -16.7 [-50.0; 0.0] n=3 | +16.7 [-50.0; 100.0] n=3 | +0.0 [0.0; 0.0] n=2 | — |
| gemini-3.5-flash (none), 2026-09-25, *parcial 94/480* | +11.1 [0.0; 37.5] n=9 | -9.1 [-41.7; 22.2] n=11 | +12.5 [0.0; 42.9] n=8 | -20.0 [-50.0; 0.0] n=10 |
| gemini-3.8-flash (none), 2026-09-25, *parcial 89/480* | +7.1 [0.0; 25.0] n=7 | +5.0 [-25.0; 35.7] n=10 | +12.5 [0.0; 40.0] n=8 | +12.5 [0.0; 42.9] n=8 |
| gemini-3.1-flash-lite (none), 2026-09-26, *parcial 348/480* | -0.8 [-4.6; 2.5] n=40 | -4.1 [-11.6; 1.9] n=37 | -1.0 [-7.8; 5.2] n=34 | -5.0 [-15.4; 4.5] n=37 |

### Latencia M4.1 y llamadas al modelo M4.4 (medianas por tarea)

| Corrida | B0 | B1 | B2 | B3 |
| --- | --- | --- | --- | --- |
| gpt-4.1-mini-2025-04-14, 2026-09-25 | 2817 ms / 2 llam. | 2735 ms / 2 llam. | 5190 ms / 4 llam. | 5225 ms / 5 llam. |
| gpt-5.4-2026-03-05, 2026-09-25 | 4540 ms / 3 llam. | 4806 ms / 3 llam. | 9784 ms / 7 llam. | 10199 ms / 7 llam. |
| gpt-5.4-mini-2026-03-17, 2026-09-25 | 2766 ms / 3 llam. | 2897 ms / 3 llam. | 6601 ms / 7 llam. | 7415 ms / 7 llam. |
| gpt-5.5-2026-04-23, 2026-09-25 | 5517 ms / 3 llam. | 5818 ms / 3 llam. | 12188 ms / 7 llam. | 12201 ms / 7 llam. |
| unihelp-qwen2.5:7b-instruct-q4_K_M-ctx16k, 2026-09-25 | 5518 ms / 2 llam. | 5349 ms / 2 llam. | 8419 ms / 4 llam. | 8781 ms / 4 llam. |
| gpt-5.5-2026-04-23, 2026-09-25, 1 rep. | 5688 ms / 3 llam. | 5541 ms / 3 llam. | 11230 ms / 7 llam. | 11352 ms / 7 llam. |
| gemini-3.1-flash-lite (none), 2026-09-25, *parcial 136/480* | 2524 ms / 2 llam. | 3133 ms / 3 llam. | 7086 ms / 8 llam. | 7550 ms / 8 llam. |
| gemini-3.1-pro-preview (low), 2026-09-25, *parcial 35/480* | 12039 ms / 2 llam. | 9775 ms / 2 llam. | 29880 ms / 6 llam. | 39657 ms / 8 llam. |
| gemini-3.5-flash (none), 2026-09-25, *parcial 94/480* | 4183 ms / 3 llam. | 3532 ms / 2 llam. | 10344 ms / 8 llam. | 12136 ms / 9 llam. |
| gemini-3.8-flash (none), 2026-09-25, *parcial 89/480* | 4952 ms / 4 llam. | 5046 ms / 3 llam. | 10556 ms / 8 llam. | 10500 ms / 8 llam. |
| gemini-3.1-flash-lite (none), 2026-09-26, *parcial 348/480* | 2758 ms / 2 llam. | 2922 ms / 2 llam. | 6732 ms / 7 llam. | 7701 ms / 8 llam. |

### Herramientas, calidad, seguridad y costo (B0 / B1 / B2 / B3)

| Corrida | M2.2 invoca prohibida % | M3.1 fidelidad % | M5.3 pide confirmacion % | M5.1 escrituras sin token | M4.7 USD de la corrida |
| --- | --- | --- | --- | --- | --- |
| gpt-4.1-mini-2025-04-14, 2026-09-25 | 4 / 8 / 11 / 13 | 100 / 100 / 98 / 100 | 57 / 62 / 86 / 71 | 0 | 1.57 |
| gpt-5.4-2026-03-05, 2026-09-25 | 0 / 0 / 0 / 0 | 99 / 99 / 100 / 99 | 90 / 86 / 86 / 86 | 0 | 11.49 |
| gpt-5.4-mini-2026-03-17, 2026-09-25 | 1 / 4 / 22 / 22 | 97 / 96 / 100 / 100 | 57 / 62 / 95 / 90 | 0 | 2.75 |
| gpt-5.5-2026-04-23, 2026-09-25 | 0 / 0 / 0 / 0 | 99 / 99 / 100 / 100 | 95 / 100 / 100 / 100 | 0 | 21.91 |
| unihelp-qwen2.5:7b-instruct-q4_K_M-ctx16k, 2026-09-25 | 5 / 5 / 3 / 4 | 92 / 84 / 61 / 62 | 10 / 5 / 14 / 0 | 0 | 0.00 |
| gpt-5.5-2026-04-23, 2026-09-25, 1 rep. | 0 / 0 / 0 / 0 | 99 / 99 / 100 / 100 | 100 / 100 / 100 / 100 | 0 | 7.57 |
| gemini-3.1-flash-lite (none), 2026-09-25, *parcial 136/480* | 4 / 12 / 21 / 15 | 100 / 100 / 100 / 100 | 100 / 100 / 100 / 100 | 0 | 0.66 |
| gemini-3.1-pro-preview (low), 2026-09-25, *parcial 35/480* | 0 / 17 / 0 / 14 | 100 / 100 / 100 / 100 | 100 / — / 100 / 100 | 0 | 1.65 |
| gemini-3.5-flash (none), 2026-09-25, *parcial 94/480* | 0 / 6 / 10 / 11 | 100 / 100 / 100 / 100 | 100 / 100 / 100 / 100 | 0 | 2.87 |
| gemini-3.8-flash (none), 2026-09-25, *parcial 89/480* | 0 / 0 / 0 / 0 | 100 / 100 / 100 / 100 | 75 / 100 / 100 / 100 | 0 | 1.88 |
| gemini-3.1-flash-lite (none), 2026-09-26, *parcial 348/480* | 10 / 9 / 14 / 13 | 100 / 100 / 100 / 100 | 100 / 100 / 100 / 100 | 0 | 1.68 |

Lectura: el control de escritura (M5.1, M5.4, M5.7) da cero en todos los
modelos; pedir confirmacion (M5.3) y no invocar herramientas prohibidas (M2.2)
depende del modelo y, en los pequeños, del multiagente. Detalle en
`informes/resultados-2026-09-27-metricas-m2-m3-m5-y-costo.md`.

Lectura de conjunto (detalle en `informes/`): MCP (B1 - B0) no cambia ni la
efectividad ni la latencia con ningun modelo (todos sus intervalos de M1.1
incluyen el cero en las corridas completas); el multiagente (B2 - B1) duplica la
latencia (de +2 a +7 s segun el modelo) y suma de 6 000 a 10 000 tokens por
ejecucion por las llamadas extra al modelo, y con modelos pequeños pierde
efectividad (Qwen2.5 7B: -20,8 puntos, intervalo que excluye el cero; gpt-5.4-mini:
-10); A2A frente a en proceso
(B3 - B2) cuesta de decenas a cientos de milisegundos y ningun token. Las
latencias absolutas entre campañas corridas en momentos o maquinas distintas no
se comparan (RM-17); efectividad, llamadas y tokens si.

---

## 7. Como trabajar con estos datos

**Excel o Sheets:** abrir `consolidado/ejecuciones.csv` (UTF-8, coma, punto
decimal) y filtrar por `clasificacion` = `A-principal`.

**Python:**

```python
import pandas as pd
ej = pd.read_csv('consolidado/ejecuciones.csv', encoding='utf-8-sig')
met = pd.read_csv('consolidado/metricas-calculadas.csv', encoding='utf-8-sig')
con = pd.read_csv('consolidado/contrastes.csv', encoding='utf-8-sig')
principal = ej[ej.clasificacion == 'A-principal']
# Ejemplo descriptivo: motivos de fallo por modelo y arquitectura
principal[principal.exito == False].groupby(['modelo_id', 'arquitectura']).motivos_fallo.value_counts()
```

**Recalcular las metricas oficiales** (la unica via valida, RM-02): desde el
repositorio,

```bash
cd experiment
uv run papermill analisis.ipynb salida.ipynb -p directorio_corrida resultados/<carpeta> -p directorio_salidas /tmp/<carpeta>
```

Cualquier agregado hecho a mano sobre `ejecuciones.csv` es exploratorio; la
cifra que se reporta es la del cuaderno.

---

## 8. Limitaciones y decisiones pendientes (RM-17)

- **Juez:** Claude (Opus 5.5) en un flujo de 78 agentes con el prompt v2, sin temperatura controlable; consistencia
  del 98,8 % contra una pasada anterior sobre 480 ejecuciones. Falta validarlo contra revisores humanos (M7.5).
  Los agentes no marcaron igual `puntos_sin_respaldo` en los puntos de prioridad (el veredicto no cambia).
- **Un extracto por politica:** `buscar_politica` entrega un solo extracto por politica; la mayoria de las
  reprobaciones del juez se deben a puntos cuya informacion nunca llego al agente (decision 53).
- **Cache de contexto (D2, decision 23):** OpenAI y Gemini cachean prompts largos
  sin opcion de apagarlo; queda registrado en `cached_input_tokens`.
- **Costo de lista:** M4.7 usa la tarifa publicada el 27 de septiembre de 2026 (`catalogo/tarifas.yaml`), sin
  descuentos ni recargos; el de gemini-3.1-pro-preview queda subestimado (su pensamiento no esta en la traza) y
  el de gemini-3.8-flash es promocional hasta el 31-12-2026.
- **M3.5 sobre 5 tareas** y **M5.2/M5.6 sin poner a prueba** (decision 51).
- **Campañas Gemini incompletas:** no se mezclan con otra corrida para completar
  la matriz sin registrar antes la decision.
- **Decisiones del equipo abiertas:** P1 (citacion en T-COM-009), P2 (T-INF-010)
  y P3 (razonamiento del modelo); T-COM-009 y T-INF-010 fallan en casi todas las
  corridas por esas causas.
- **Latencia entre campañas:** las campañas OpenAI corrieron en paralelo en la misma maquina; comparar latencias absolutas entre modelos es una decision aparte.
- **Datos sinteticos (RNF-05):** ninguna tarea ni traza contiene datos personales reales.
